# 对齐 OPC-skill 的角色体系（待更新依据）

> 依据：`D:\仓库\OPC-skill`（GitHub `r9412460971-cloud/OPC-skill`，本地 commit `a4b2d47`，93 个 skill）
> 结论：**一人投顾包的 roles 应该照这里改**，OPC-skill 里已经有成熟的投顾公司角色，只是写成了「公司架构」，需要压成「一人兼岗」。

---

## 一、OPC-skill 的 16 个 r9-opc-* 角色

| Skill | 角色 | 姓名 | 管什么 |
|---|---|---|---|
| r9-opc-ceo | CEO | — | 战略与资源分配 |
| **r9-opc-advisory** | 投顾服务部总经理 | **Mira** | 全公司客户服务、投顾咨询、客户陪伴、ToC 运营 |
| r9-opc-advisory-strategy | 顾问策略师 | **Aiden** | 服务产品设计、客户旅程、服务分层、服务标准 |
| r9-opc-advisory-content | 内容运营官 | **Belle** | 内容策略、多形态生产、IP 运营 |
| r9-opc-advisory-success | 客户成功经理 | **Clara** | 分层运营、生命周期、续约增购、NPS |
| r9-opc-advisory-delivery | 投顾交付主管 | **Dylan** | 方案一线交付、沟通执行、投后跟踪 |
| **r9-opc-compliance** | 合规风控总经理 | **Sage** | 适当性、营销合规、披露、反洗钱、内控审计 |
| r9-opc-operations | 运营 | — | 中后台、流程、数据 |
| r9-opc-research | 研究总控 | — | 研究调度 |
| r9-opc-research-fund / -asset / -macro / -portfolio / -sector | 分板块研究员 | — | 基金 / 资产 / 宏观 / 组合 / 行业 |
| r9-opc-memory | 记忆 | — | 沉淀与召回 |
| r9-workbench | 超级路由 | — | 统管 87–93 个 skill，用户说人话它选工具 |

## 二、和「一人投顾包」原来的 roles 对比

| SoloAdvisor-Toolkit 原 roles（错） | OPC-skill 里的对应角色 |
|---|---|
| ceo | r9-opc-ceo |
| em（工程经理） | r9-opc-advisory-strategy（Aiden） |
| engineer（工程师） | r9-opc-research-*（研究员）+ research-portfolio（配置） |
| qa（质量） | **r9-opc-compliance**（Sage） |
| release（发布） | r9-opc-advisory-delivery（Dylan） |
| devops（运维） | r9-opc-operations |
| —（缺） | r9-opc-advisory-success（Clara）+ advisory-content（Belle） |

## 三、压成一人投顾的六个帽子

| 帽子 | 来自 OPC-skill | 什么时候戴 |
|---|---|---|
| 客户顾问 | advisory-delivery（Dylan）+ advisory-success（Clara） | 全程，尤其见面与沟通 |
| 投资研究员 | r9-opc-research-fund/asset/macro/sector | 有候选产品时 |
| 资产配置师 | r9-opc-research-portfolio + advisory-strategy（Aiden） | KYC 齐了之后 |
| 合规与适当性 | r9-opc-compliance（Sage） | 方案定稿、对外发布前 |
| 投后服务 | advisory-success（Clara） + post-investment-companion | 交付之后，每季 |
| 运营与数据 | r9-opc-operations | 建档、归档、对账 |

外加一组 OPC-skill 里没有的：**跨专业顾问（法律 / 税务 / 保险 / 信托）**——一人投顾不常备，触发即叫。

## 四、更新动作（下次做）

1. 删掉 `roles/ceo|em|engineer|qa|release|devops`
2. 换成六顶帽子 + 跨专业顾问组（本机 `plus/roles/` 已写好一版）
3. 把 OPC-skill 里 r9-opc-* 的「部门职责」压缩成「一人兼岗的时段分配」
4. 保留 r9-workbench 的思路：**用户说人话，工作台负责路由**——这正好是 V1/V2/V3 三版的共同入口设计
