# 验收清单

## A 能跑
- [ ] `python check.py` 通过（提醒可以有，失败必须 0）
- [ ] `python board.py` 生成 `02-board.md`，七段都在
- [ ] `python res.py 跌了` 有命中
- [ ] `python calendar.py today` 不报错

## B 是自己的
- [ ] 14 张表里的 SAMPLE 行全部替换
- [ ] products.csv 的「适合谁」「一句话话术」自己写过
- [ ] templates/ 至少 4 个改成自己的口吻

## C 能干活
- [ ] 一个真实客户走完：建档 → 接话 → 方案 → Gate → 一页纸 → 落 outputs
- [ ] 发一条素材给 3 个客户，记进 sends.csv
- [ ] 开一场沙龙，名单和跟进记进 events/invites

## D 会沉淀
- [ ] sediment.py 沉过一条；review.py 批准过；sync.py --write 回流过

## E 守规矩
- [ ] act.py install 不加 --yes 只打印计划
- [ ] 客户资料没出过这个目录