"""体检：7 个 Gate + 数据完整性（v2 全量版）

跑法：python check.py
覆盖：Gate1 KYC完整 / Gate2 适当性 / Gate3 风险揭示 / Gate4 集中度 / Gate5 换手 / Gate6 费用 / Gate7 业绩声明
      另查：数据表字段、示例行是否还在、产物命名
"""
import csv, os, sys, re, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "outputs")
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass

ok, warn, err = [], [], []

def need(fn, cols):
    p = os.path.join(DATA, fn)
    if not os.path.exists(p):
        err.append(f"缺文件 data/{fn}"); return []
    with open(p, encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
        head = rows[0].keys() if rows else []
    miss = [c for c in cols if c not in head]
    if miss: err.append(f"data/{fn} 缺字段：{'、'.join(miss)}")
    else: ok.append(f"data/{fn} 字段齐（{len(rows)} 行）")
    return rows

clients = need("clients.csv", ["客户ID","称谓","分群","阶段","资金期限","可承受回撤","风险等级","下次联系日","他真正担心什么"])
products = need("products.csv", ["产品ID","名称","风险等级","费率","适合谁","一句话话术"])
materials = need("materials.csv", ["素材ID","标题","配好的话术"])

# Gate 1：KYC 五字段
for c in clients:
    miss = [k for k in ["资金期限","可承受回撤","风险等级","目标","他真正担心什么"] if not (c.get(k) or "").strip()]
    if miss: warn.append(f"Gate1 {c.get('称谓')}：缺 {'、'.join(miss)}")

# Gate 2：适当性（产品 R ≤ 客户 C）
RANK = {"R1":1,"R2":2,"R3":3,"R4":4,"R5":5}
C2R = {"C1":"R1","C2":"R2","C3":"R3","C4":"R4","C5":"R5"}
for c in clients:
    lvl = (c.get("风险等级") or "").strip()
    if lvl not in C2R: continue
    bad = [p["名称"] for p in products if RANK.get((p.get("风险等级") or "").strip(), 0) > RANK[C2R[lvl]]]
    if bad: warn.append(f"Gate2 {c.get('称谓')}（{lvl}）：不适合 {'、'.join(bad)}")

# Gate 3/6/7：模板层面检查
tpl_dir = os.path.join(ROOT, "templates")
for fn, gate in [("一页纸.md","Gate3"), ("配置建议书.md","Gate6"), ("季度复盘.md","Gate7")]:
    p = os.path.join(tpl_dir, fn)
    if not os.path.exists(p):
        err.append(f"缺模板 templates/{fn}"); continue
    t = open(p, encoding="utf-8").read()
    if gate == "Gate3" and "最坏" not in t: err.append("Gate3 一页纸缺「最坏会怎样」段")
    if gate == "Gate6" and "费率" not in t and "费用" not in t: warn.append("Gate6 建议书未含费用披露段")
    if gate == "Gate7" and "不代表未来" not in t and "不构成投资建议" not in t: warn.append(f"Gate7 {fn} 缺业绩声明")
ok.append("Gate3/6/7 模板检查完成")

# Gate 4：集中度阈值可算（按等级）
TH = {"C1":(20,40,30),"C2":(20,40,30),"C3":(30,50,40),"C4":(40,60,50),"C5":(40,60,50)}
for c in clients:
    lvl=(c.get("风险等级") or "").strip()
    if lvl in TH:
        p_max,a_max,o_max = TH[lvl]
        ok.append(f"Gate4 {c.get('称谓')}：单产品 {p_max}% / 单类 {a_max}% / 单机构 {o_max}%")

# Gate 5：换手（从 kpi.csv 读，没有就跳过）
kp = os.path.join(DATA,"kpi.csv")
if os.path.exists(kp):
    with open(kp, encoding="utf-8-sig") as f:
        ok.append(f"Gate5：kpi.csv 可读（{len(list(csv.DictReader(f)))} 行），换手率需人工填")

# 示例行提示
for name, rows in [("clients.csv", clients), ("products.csv", products), ("materials.csv", materials)]:
    n = sum(1 for r in rows if "SAMPLE" in str(r))
    if n: warn.append(f"data/{name} 还有 {n} 行 SAMPLE 示例，记得换成你自己的")

# 产物命名
if os.path.isdir(OUT):
    files=[f for f in os.listdir(OUT) if f.endswith(".md")]
    PAT=re.compile(r"^\d{8}-.+\.md$")
    bad=[f for f in files if not PAT.match(f)]
    if bad:
        for f in bad: err.append(f"产物命名不合规：{f}（应为 YYYYMMDD-客户-类型.md）")
    elif files: ok.append(f"产物命名合规（{len(files)} 份）")

print("="*58)
for m in ok: print("  [OK] "+m)
for m in warn: print("  [!!] "+m)
for m in err: print("  [XX] "+m)
print("="*58)
print(f"通过 {len(ok)} · 提醒 {len(warn)} · 失败 {len(err)}")
sys.exit(1 if err else 0)
