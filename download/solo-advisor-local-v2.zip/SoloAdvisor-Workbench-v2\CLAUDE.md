# CLAUDE.md — 一人投顾工作台（v2）

> **最重要的一条：顾问不填表。他说话，你写表。**
> 写入规则见 `AGENT-WRITE.md`（14 张表全覆盖，含说什么→写哪张表）。

## 目录
- `data/` 14 张表 = 唯一真源（**由你写，不是顾问填**）
- `templates/` 14 个交付物
- `resources/` 弹药库（场景33/工具28/Skill51/库75/模板20）
- `clients/` 一人一档，`outputs/` 产物，`inbox/` 收件

## 每轮对话固定动作
1. 听顾问说话 → 判断哪句该落表（对照 `AGENT-WRITE.md` 第一节）
2. 用 `python log.py …` 写入（追加或更新，不确定问一句）
3. 收尾跑三件：`python links.py`、`python board.py`、`python check.py`
4. 给顾问一句人话总结（不要报「写入了第几行」）

## 干活顺序
1. 读 `00-identity.md`、`01-rules.md`
2. `python res.py <关键词>` 查弹药
3. 在 `data/clients.csv` 里找客户；没有就先建档
4. 按七步走，每步对一眼 Gate
5. 产物落 `outputs/YYYYMMDD-客户-类型.md`，四行留痕
6. 收工跑 board + check

## 硬规则
- **顾问只说话，表由你写**（`AGENT-WRITE.md`）
- 拿不到的数据不编（AUM/持仓/佣金不是他的，别装）
- 不覆盖「他真正担心什么」，除非顾问明说
- 外部动作先问（`act.py`）
- 用出来的东西必须沉淀（`sediment.py`）
- 不承诺收益、不替客户决定

## 常用指令
| 顾问说 | 你做 |
|---|---|
| 今天见了 X / 跟他聊完 | 记沟通 + 他说的关键一句 |
| 他问「…」 | 查场景 → 三句话 → 记 feedback |
| 给他发了 X | 记 sends |
| 约了他 X 日 | 记下次联系 + 生成 .ics |
| 产品 X 出事了 | 改状态 → 刷看板 → 报受影响客户 |
| 今天该做什么 | 跑 board.py |
| 出方案 | 三输入 → 算 → 模板 → 过 Gate |
