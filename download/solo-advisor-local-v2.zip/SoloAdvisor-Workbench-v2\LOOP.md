# 沉淀闭环与授权规矩

> 2026-11-26 定稿。两条规矩来自你的要求：**任何外部动作先问；用出来的东西必须沉下来。**

---

## 一、沉淀闭环（三件套）

```
客户说了一句话
   ↓ 抄进 inbox/
sediment.py     把它沉成一条 local 记录（status=pending）
   ↓
review.py       每周过一遍：a 批准 / r 驳回
   ↓
sync.py         把 approved 合并回 resources/_all.json
   ↓
站点下次更新     把 origin=local 的条目带进 index.html
```

| 命令 | 作用 | 输出 |
|---|---|---|
| `python sediment.py scene "客户说：…" "先接一句：…" --tag 家人` | 沉一条新场景 | `resources/local/scenes.json` + `local-scene-001` |
| `python sediment.py template "我的三句话卡片" "…"` | 沉一个新模板 | `resources/local/templates.json` |
| `python review.py` | 列出待复核 | 带编号 |
| `python review.py a 1` | 批准 | status → approved |
| `python review.py r 2` | 驳回 | status → rejected（不删，留证据） |
| `python sync.py` | 回流（dry run） | 显示会合并几条 |
| `python sync.py --write` | 真写 | 写进 `_all.json`，标 `origin=local` |

**三条硬规则**：

1. 只写 `resources/local/`，**不动**站点导出的原始 JSON
2. **pending 不参与任何检索结果**（避免污染）
3. 站点回流只取 `approved`，且带日期与来源

---

## 二、授权闸门（act.py）

你要的规矩：**装 Skill、开工具、联网抓，必须先问。**

| 动作 | 命令 | 不加 `--yes` 时 |
|---|---|---|
| 装 Skill | `python act.py install 估值建模教练` | 只打印：Skill 名、作用、来源、链接、是否需要登录 + 手动执行方式 |
| 联网查 | `python act.py fetch 理杏仁` | 只打印：工具、用途、地址、能不能自动 |
| 看规矩 | `python act.py list` | 列出两类动作与白名单 |

**实测输出（未确认，什么都没做）**：

```
=== 即将执行：安装 Skill ===
  Skill   ：估值建模教练（组合构建与优化）
  作用    ：不依赖付费库的 DCF 与相对估值双轨对照
  链接    ：https://skillhub.cn/skills/kunlungrowth/valuation-modeling-coach
  需要登录：是

  未确认，什么都没做。
  确认要装：python act.py install 估值建模教练 --yes
```

**白名单**：只有公开页面能自动抓——`韭圈儿 / 理杏仁 / 天天基金 / 集思录 / 晨星中国`。

**登录墙一律交给人**：

```
=== 即将执行：联网查数据 ===
  工具    ：慧博投研
  能否自动：不能（要登录/付费，只能你自己开）
  你要自己打开：https://www.hibor.com.cn
```

---

## 三、和 Agent 的约定（写进 CLAUDE.md）

| 场景 | Agent 该做什么 | 不该做什么 |
|---|---|---|
| 命中一个 Skill | 打印安装计划 + 问「要不要装」 | 自己装、自己下载 |
| 需要查数据 | 先看白名单；在白名单里就问「要不要查」 | 不问就抓、抓登录墙 |
| 发现新话术/新模板 | 跑 `sediment.py` 沉下来，标 pending | 直接改站点、直接当 approved 用 |
| 客户资料 | 只留本地 | 上传任何云端 |

---

## 四、每周十分钟的固定动作

| 周几 | 干什么 | 命令 |
|---|---|---|
| 周一 | 刷看板，看这周该联系谁 | `python board.py` |
| 周一 | 体检：字段/指标/产物命名 | `python plus/checks/check.py` |
| 周五 | 过一遍本周沉淀 | `python review.py` → `a/r` |
| 周五 | 回流已批准的 | `python sync.py --write` |
