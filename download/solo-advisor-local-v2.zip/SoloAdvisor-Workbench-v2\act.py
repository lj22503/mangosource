"""外部动作的确认闸门：装 Skill / 打开工具 / 联网抓数据，一律先问

用法：
    python act.py list                     看有哪些动作待授权
    python act.py install 估值建模教练       计划装一个 skill（不会真装）
    python act.py install 估值建模教练 --yes 确认后才打开链接
    python act.py fetch 韭圈儿              计划联网查（不会真抓）
    python act.py fetch 韭圈儿 --yes        确认后给出抓取方案

设计原则（用户要求）：
1. 任何「装东西」「打开外部工具」「联网抓数据」的动作，都必须先打印计划并要求 --yes
2. 不加 --yes 时只打印计划 + 人工执行方式，绝不偷偷执行
3. 需要登录态的（ima / SkillHub / 付费工具），一律交给人在浏览器里做
"""
import json, os, sys, webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
ALL = os.path.join(ROOT, "resources", "_all.json")

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# 可联网抓取的公开工具白名单（其余一律只给链接）
AUTO_FETCH_OK = {"韭圈儿", "理杏仁", "天天基金", "集思录", "晨星中国"}


def load():
    with open(ALL, encoding="utf-8") as f:
        return json.load(f)


def flat_tools(d):
    out = []
    for g in d.get("TOOLS", []):
        if isinstance(g, list) and len(g) >= 2:
            for t in g[1]:
                out.append({"layer": g[0], "name": t[0], "desc": t[1], "kind": t[2], "url": t[3]})
    return out


def find_skill(d, name):
    for s in d.get("SKILLS", []):
        if name in s[1]:
            return s
    return None


def find_tool(d, name):
    for t in flat_tools(d):
        if name in t["name"]:
            return t
    return None


def install(name, yes):
    d = load()
    s = find_skill(d, name)
    if not s:
        print(f"[!] 没找到 Skill：{name}。先 python res.py {name}")
        return
    print("\n=== 即将执行：安装 Skill ===")
    print(f"  Skill   ：{s[1]}（{s[0]}）")
    print(f"  作用    ：{s[2]}")
    print(f"  来源    ：{s[5]}")
    print(f"  链接    ：{s[6]}")
    print(f"  需要登录：{'是' if 'skillhub' in s[6] else '可能要（GitHub 公开则否）'}")
    if not yes:
        print("\n  未确认，什么都没做。")
        print(f"  确认要装：python act.py install {name} --yes")
        print("  （你也可以自己在浏览器打开上面的链接装）")
        return
    print("\n  已确认，打开安装页…")
    webbrowser.open(s[6])
    print("  剩下手动三步：① 页面点安装/复制安装命令 ② 客户端里确认 ③ 重启客户端")


def fetch(name, yes):
    d = load()
    t = find_tool(d, name)
    if not t:
        print(f"[!] 没找到工具：{name}。先 python res.py {name}")
        return
    ok = t["name"] in AUTO_FETCH_OK or any(x in t["name"] for x in AUTO_FETCH_OK)
    print("\n=== 即将执行：联网查数据 ===")
    print(f"  工具    ：{t['name']}（{t['layer']}·{t['kind']}）")
    print(f"  用途    ：{t['desc']}")
    print(f"  地址    ：{t['url']}")
    print(f"  能否自动：{'能（公开页面）' if ok else '不能（要登录/付费，只能你自己开）'}")
    if not ok and not yes:
        print("\n  这一个是登录墙/付费墙，工作台抓不了。")
        print(f"  你要自己打开：{t['url']}")
        return
    if not yes:
        print("\n  未确认，什么都没做。")
        print(f"  确认要查：python act.py fetch {name} --yes")
        return
    print("\n  已确认。抓取计划：")
    print("    ① 打开页面 → ② 抓关键数字（估值/回撤/费率）→ ③ 落 outputs/ 作为「依据」")
    print("    注意：抓来的是页面快照，不是 API；数字要标日期与来源")
    webbrowser.open(t["url"])


def cmd_list():
    print("需要授权的动作，只有两类：\n")
    print("  ① 装 Skill      python act.py install <名字>        （加 --yes 才执行）")
    print("  ② 联网查工具    python act.py fetch <名字>          （加 --yes 才执行）")
    print("\n规则：不加 --yes 只打印计划，绝不偷偷执行；需要登录的一律交给你。")
    print(f"\n可自动抓的公开工具白名单：{'、'.join(sorted(AUTO_FETCH_OK))}")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--yes"]
    yes = "--yes" in sys.argv
    if not args or args[0] == "list":
        cmd_list()
    elif args[0] == "install" and len(args) > 1:
        install(" ".join(args[1:]), yes)
    elif args[0] == "fetch" and len(args) > 1:
        fetch(" ".join(args[1:]), yes)
    else:
        print(__doc__)
