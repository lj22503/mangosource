"""复核：把 resources/local/ 里 pending 的条目，逐条过一遍

用法：
    python review.py            # 列出所有待复核
    python review.py 1          # 看第 1 条的全文
    python review.py a 1        # 批准第 1 条
    python review.py r 1        # 驳回第 1 条（标记 rejected，不删）
"""
import json, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
LOCAL = os.path.join(ROOT, "resources", "local")
FILES = {"scene": "scenes.json", "template": "templates.json", "tool": "tools.json", "skill": "skills.json", "kb": "kb.json"}

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def load_all():
    items = []
    for kind, fn in FILES.items():
        p = os.path.join(LOCAL, fn)
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8") as f:
            for x in json.load(f):
                items.append((kind, fn, x))
    return items


def save_kind(fn, data):
    with open(os.path.join(LOCAL, fn), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def cmd_list(items):
    pend = [(k, f, x) for k, f, x in items if x.get("status") == "pending"]
    if not pend:
        print("没有待复核的条目。")
        return
    print(f"待复核 {len(pend)} 条：\n")
    for i, (k, f, x) in enumerate(pend, 1):
        print(f"  [{i}] {x['id']}  ({k})  {x['title']}")
        print(f"      {x['date']} · {x.get('source','')} · {x.get('tag','')}")
        print(f"      {x['body'][:60]}{'…' if len(x['body'])>60 else ''}")
    print("\n看详情：python review.py <序号>")
    print("批准：  python review.py a <序号>")
    print("驳回：  python review.py r <序号>")


def cmd_show(items, idx):
    pend = [(k, f, x) for k, f, x in items if x.get("status") == "pending"]
    if not (1 <= idx <= len(pend)):
        print("序号超范围")
        return
    k, f, x = pend[idx - 1]
    print(json.dumps(x, ensure_ascii=False, indent=2))


def cmd_set(items, idx, status):
    pend = [(k, f, x) for k, f, x in items if x.get("status") == "pending"]
    if not (1 <= idx <= len(pend)):
        print("序号超范围")
        return
    k, f, x = pend[idx - 1]
    p = os.path.join(LOCAL, f)
    with open(p, encoding="utf-8") as fh:
        data = json.load(fh)
    for it in data:
        if it["id"] == x["id"]:
            it["status"] = status
    save_kind(f, data)
    print(f"[OK] {x['id']} → {status}")


if __name__ == "__main__":
    items = load_all()
    args = sys.argv[1:]
    if not args:
        cmd_list(items)
    elif len(args) == 1 and args[0].isdigit():
        cmd_show(items, int(args[0]))
    elif len(args) == 2 and args[0] == "a":
        cmd_set(items, int(args[1]), "approved")
    elif len(args) == 2 and args[0] == "r":
        cmd_set(items, int(args[1]), "rejected")
    else:
        print(__doc__)
