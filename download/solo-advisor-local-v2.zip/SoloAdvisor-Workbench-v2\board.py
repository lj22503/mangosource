"""看板：读 data/clients.csv → 写 02-board.md

跑法：python board.py
"""
import csv, os, sys, datetime
import links
from collections import OrderedDict

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "02-board.md")
STAGES = ["线索","已见面","方案中","已交付","投后","沉睡"]
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass

def rows(fn):
    p = os.path.join(DATA, fn)
    if not os.path.exists(p): return []
    with open(p, encoding="utf-8-sig") as f: return list(csv.DictReader(f))

def days(iso):
    if not iso: return None
    try: d = datetime.date.fromisoformat(iso.strip())
    except ValueError: return None
    return (d - datetime.date.today()).days

def main():
    cs, ms, tk, ev = rows("clients.csv"), rows("materials.csv"), rows("talk.csv"), rows("events.csv")
    today = datetime.date.today().isoformat()
    L = ["# 客户看板（" + today + " 生成）", "", "> 共 " + str(len(cs)) + " 个客户。渲染产物，别手改；改 data/clients.csv 后重跑。", ""]

    L += ["## 一、主看板", ""]
    by = OrderedDict((s, []) for s in STAGES)
    for c in cs: by.setdefault((c.get("阶段") or "").strip(), []).append(c)
    for st in STAGES:
        g = by.get(st, [])
        L.append("### " + st + "（" + str(len(g)) + "）"); L.append("")
        if g:
            for c in g:
                d = days(c.get("下次联系日"))
                flag = "" if d is None else (" 逾期" + str(-d) + "天" if d < 0 else (" 今天" if d == 0 else " · " + str(d) + "天后"))
                L.append("- **" + (c.get("称谓") or "?") + "**（" + (c.get("分群") or "—") + "）" + (c.get("资金期限") or "") + " · " + (c.get("风险等级") or "未测评") + flag)
        else:
            L.append("_（空）_")
        L.append("")

    due = sorted([c for c in cs if days(c.get("下次联系日")) is not None and days(c.get("下次联系日")) <= 7], key=lambda c: days(c.get("下次联系日")))
    L += ["## 二、本周该联系", ""]
    L += ["- **" + c.get("称谓", "") + "**　" + str(days(c.get("下次联系日"))) + " 天后　他的担心：" + (c.get("他真正担心什么") or "—") for c in due] or ["_（这周没有到期的）_"]
    L.append("")

    L += ["## 三、Gate 待补（发东西前先看）", ""]
    gate = []
    for c in cs:
        miss = [k for k in ["资金期限","可承受回撤","风险等级","目标","他真正担心什么"] if not (c.get(k) or "").strip()]
        if miss: gate.append("- **" + c.get("称谓", "") + "**　缺：" + "、".join(miss) + "（Gate 1）")
    L += gate or ["_（没有缺项）_"]
    L.append("")

    L += ["## 四、沉默（60 天没联系）", ""]
    sl = [c for c in cs if days(c.get("上次沟通")) is not None and days(c.get("上次沟通")) <= -60]
    L += ["- **" + c.get("称谓", "") + "**　已 " + str(-days(c.get("上次沟通"))) + " 天" for c in sl] or ["_（都在跟进中）_"]
    L.append("")

    L += ["## 五、今天能发什么", ""]
    L += ["- **" + (m.get("标题") or "") + "**（" + (m.get("类型") or "") + "）→ " + (m.get("配好的话术") or "") for m in ms] or ["_（素材库空着，收一条）_"]
    L.append("")
    L += ["## 六、话术卡", ""]
    L += ["- " + (t.get("场景") or "") + "：" + (t.get("先接一句") or "") for t in tk] or ["_（话术库空着）_"]
    L.append("")
    L += ["## 七、近期活动", ""]
    L += ["- " + (e.get("名称") or "") + " " + (e.get("日期") or "") + " " + (e.get("时间") or "") + "　" + (e.get("主题") or "") + "　状态：" + (e.get("状态") or "") for e in ev] or ["_（没有排期）_"]
    L.append("")

    # 八、产品视图（谁关心这个产品）—— 关系由 links.py 自动生成
    rels = links.build()
    prod = rows("products.csv")
    L += ["## 八、产品视图（出事时通知谁）", ""]
    if prod:
        for p_ in prod:
            pid = (p_.get("产品ID") or "").strip()
            holders = sorted({r["来源ID"] for r in rels if r["关系"] == "提到" and r["目标类型"] == "产品" and r["目标ID"] == pid})
            names = []
            for cid in holders:
                nm = next((c.get("称谓") for c in cs if (c.get("客户ID") or "").strip() == cid), cid)
                names.append(nm)
            status = (p_.get("状态") or "").strip()
            flag = " ⚠ 需关注" if status and status not in ("在售",) else ""
            L.append(f"- **{p_.get('名称','')}**（{p_.get('风险等级','')}）状态：{status or '—'}{flag}　提到过的客户 {len(names)} 人：{'、'.join(names) or '—'}")
    else:
        L.append("_（产品库空着）_")
    L.append("")

    # 九、素材视图（发了几个、回了几个）
    L += ["## 九、素材视图（发了几个、回了几个）", ""]
    ms_all = rows("materials.csv")
    if ms_all:
        for m in ms_all:
            mid = (m.get("素材ID") or "").strip()
            sent = [r["来源ID"] for r in rels if r["关系"] == "发过" and r["目标类型"] == "素材" and r["目标ID"] == mid]
            back = [r["来源ID"] for r in rels if r["关系"] == "反馈过" and r["目标类型"] == "素材" and r["目标ID"] == mid]
            L.append(f"- **{m.get('标题','')}**（{m.get('类型','')}）发给 {len(sent)} 人，有回应 {len(back)} 人")
    else:
        L.append("_（素材库空着）_")
    L.append("")

    open(OUT, "w", encoding="utf-8").write("\n".join(L))
    print("[OK] 已生成 " + OUT)
    print("     客户 %d · 本周该联系 %d · Gate 待补 %d · 沉默 %d · 素材 %d" % (len(cs), len(due), len(gate), len(sl), len(ms)))

if __name__ == "__main__": main()