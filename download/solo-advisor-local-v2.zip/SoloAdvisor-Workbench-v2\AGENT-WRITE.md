# AGENT-WRITE.md — 顾问只说话，表由你写

> 给 AI 的写入规则。**顾问永远不打开 CSV**；他说的每一句该落表的，你落。
> 工具：`python log.py <表> ...`（见文末速查）。写完顺手跑 `python board.py` + `python links.py`。

---

## 零、一句话原则

> **顾问说人话，你写结构化。写不确定就问一句，宁可空着不编。**

三个不许：
1. 不许让顾问自己填表、填字段
2. 不许编造顾问没说的信息（尤其数字、产品、期限）
3. 不许覆盖「他真正担心什么」——除非顾问明确说「改成…」

---

## 一、说什么 → 写哪张表（全覆盖，14 表）

| 顾问说 | 写哪张表 | 写什么字段 | 命令 |
|---|---|---|---|
| 「今天见了张先生」「刚跟张先生聊完」 | `clients.csv` | 上次沟通=今天 | `python log.py payment C001` |
| 「他孩子两年后出国，那 80 万不能亏」 | `clients.csv` | 他真正担心什么；目标=教育金 | `--set 他真正担心什么=… --set 目标=教育金` |
| 「他只能承受 15% 的回撤」 | `clients.csv` | 可承受回撤=15 | `--set 可承受回撤=15` |
| 「测完他是 C3」 | `clients.csv` | 风险等级=C3；测评日期=今天 | `--set 风险等级=C3 --set 测评日期=2026-11-27` |
| 「约了他下周二下午两点」 | `clients.csv` + 日历 | 下次联系日；生成 .ics | `--set 下次联系日=…` + `python calendar.py add "张先生" 2026-12-01 14:00` |
| 「他问我跌了要不要卖」 | `feedback.csv` | 反馈原话；属于哪类=情绪 | `python log.py feedback C001 "跌了要不要卖" 情绪 是` |
| 「给他发了降准那条」 | `sends.csv` | 客户/素材/日期/渠道 | `python log.py send C001 M001 微信` |
| 「他说看不懂」 | `feedback.csv` | 反馈原话；需要跟进=是 | `python log.py feedback C001 "他说看不懂" 看不懂 是` |
| 「这条素材不错，存一下」 | `materials.csv` | 标题/类型/摘要/配好的话术 | `python log.py material "标题" 宏观 "摘要" "话术"` |
| 「他问你收多少」（新场景） | `talk.csv` | 场景/先接一句/一个事实/一个下一步 | `python log.py talk "你收多少" "…" "…" "…"` |
| 「产品 XX 清盘了 / 换经理了」 | `products.csv` | 状态 | `python log.py product P002 --set 状态=清盘` |
| 「我这有只新来的短债」 | `products.csv` | 名称/类型/风险/期限/费率 | `python log.py product "XX短债" 公募债 R2 随时 0.2%` |
| 「今天沙龙来了 3 个」 | `events.csv` + `invites.csv` | 活动状态；到场 | `python log.py invite E001 C002 微信 是` |
| 「约了下月直播」 | `events.csv` | 名称/类型/日期/时间/地点/主题 | `python log.py event "月度直播" 直播 2026-12-05 20:00 线上 "四季度怎么收"` |
| 「这个月新增 3 个」 | `kpi.csv` | 新增客户=3 | `python log.py kpi 2026-11 --set 新增客户=3` |
| 「提醒我周四联系李女士」 | `tasks.csv` | 任务/关联客户/类型 | `python log.py task "联系李女士" C002 跟进` |
| 「我想写篇关于固收+的」 | `topics.csv` | 选题/来源/形态 | 见文末 |
| 「我对这只产品的理解是三句话…」 | `notes.csv` | 产品ID/我的理解三句话 | 见文末 |
| 「我新认识一个人，叫王女士」 | `clients.csv` | 称谓 + 阶段=线索 | `python log.py client "王女士" --set 阶段=线索` |
| 「张先生介绍了他同事」 | `referrals.csv` | 推荐人/被推荐人/日期 | 见文末 |

**记不住表名时**：先问自己「这句话是事实、动作、还是判断」——事实进 clients/products，动作进 sends/invites/tasks，判断进 talk/notes。

---

## 二、三种写入模式，别搞混

| 模式 | 什么时候用 | 命令形态 |
|---|---|---|
| **追加**（append） | 一件事发生了：发了素材、客户说了一句话、邀约了 | `send / feedback / invite / task / material / talk` |
| **更新**（upsert） | 一个人/产品/活动的状态变了 | `client / product / event / kpi / payment` |
| **只读**（不写） | 顾问只是问问题、要看东西 | 不写表，跑 `board.py` / `res.py` |

**判断口诀**：有「谁对谁做了什么」→ 追加；有「某个东西现在是什么状态」→ 更新。

---

## 三、什么时候先问一句

只有这四种情况要问，其余直接写：

| 情况 | 问法 |
|---|---|
| 分不清是哪个客户（「老王」有两个） | 「是张先生家的王女士，还是新认识的那位？」 |
| 关键信息缺失（说「给他发了条素材」但没说哪条） | 「发的是降准那条，还是黄金那条？」 |
| 涉及金额/期限/回撤但没给数 | 「他说能承受多少回撤？」 |
| 要覆盖已有内容（改「他真正担心什么」） | 「原来的『孩子出国那 80 万』还保留吗？」 |

**一次只问一个**，不要连着问三个。

---

## 四、每次对话结束的收尾动作（固定四步）

```bash
python links.py     # 关系自动生成（谁提到过哪个产品、素材发了几个）
python board.py     # 刷新看板（客户/产品/素材三视图）
python check.py     # 体检：7 个 Gate + 缺字段
```

然后跟顾问说一句人话总结，例如：

> 已记：张先生 11-27 沟通、发了降准那条、他回「看不懂」。
> 看板提醒：他 Gate 缺风险等级，方案还不能发。

**不要**把「我写入了 sends.csv 第 3 行」这种话给顾问看。

---

## 五、写错了怎么办

| 症状 | 处理 |
|---|---|
| 同一件事写了两遍 | 追加型表自带去重（同日期+客户+素材视为一条）；发现重复手动删行 |
| 产品名/客户名被清空 | `log.py` 只写「给了的」字段，不会清空；若已损坏，用 `--set 名称=…` 补回 |
| 写进了 SAMPLE 示例行 | 示例行末尾有 `SAMPLE`，别改它；新建自己的行 |
| 不确定字段名 | 先 `Get-Content data/<表>.csv -TotalCount 1` 看表头，再写 |

---

## 六、顾问问问题的时候（不写表，但要用表）

| 顾问问 | 你做什么 |
|---|---|
| 「今天该做什么」 | `python board.py` → 读「本周该联系」段 |
| 「张先生什么情况」 | 读 `clients.csv` + `clients/张先生*.md` + `feedback.csv` 里他的记录 |
| 「这个产品谁买过/谁问过」 | `python links.py` → 读 `links.generated.csv` 的「提到」关系 |
| 「今天发什么」 | 读 `materials.csv`，按「适合标签」∩ 客户标签配人 |
| 「他问的这句话怎么接」 | `python res.py <关键词>` → 场景卡 → 三句话 |
| 「这个产品能不能推给他」 | 读产品风险等级 vs 客户风险等级（Gate 2） |

---

## 七、log.py 速查

```
python log.py payment  C001                       # 记一次沟通（今天）
python log.py client   C004 --set 分群=成长 --set 阶段=线索
python log.py product  P002 --set 状态=暂停申购
python log.py product  "XX短债" 公募债 R2 随时 0.2%
python log.py send     C001 M001 微信
python log.py feedback C001 "看不懂" 看不懂 是
python log.py invite   E001 C002 微信 是
python log.py task     "联系李女士" C002 跟进
python log.py material "降准0.5个点" 宏观 "摘要" "话术"
python log.py event    "月度直播" 直播 2026-12-05 20:00 线上 "主题"
python log.py kpi      2026-11 --set 新增客户=3
python log.py talk     "跌了想卖" "先接一句" "一个事实" "一个下一步"
```

**全部命令都幂等**：重复跑不会产生重复行（追加型按签名去重，更新型按 ID 覆盖）。

---

## 八、边界

- 客户资料只留本地，不上传
- 不把表里的 AUM/持仓当事实——**这些表里本来就没有**
- 涉及法律/税务/保险条款，提醒找专业顾问
- 引用业绩必带「过往不代表未来」
