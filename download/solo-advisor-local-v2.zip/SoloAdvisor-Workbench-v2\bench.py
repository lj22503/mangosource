"""生成工作台界面：data/ → 工作台.html（单文件，数据内联，双击即看）

为什么这么做：WorkBuddy 的工作台是「一个能打开的页面」。
所以 AI 写完表之后，跑这个脚本，把 14 张表渲染成一个自包含的 HTML，
顾问在 WorkBuddy 里点开就是界面——不用装任何东西，也不用起服务器。

跑法：python bench.py
输出：工作台.html（含数据快照 + 生成时间）
"""
import csv, os, sys, json, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(ROOT, "工作台.html")
STAGES = ["线索", "已见面", "方案中", "已交付", "投后", "沉睡"]

try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass


def rows(fn):
    p = os.path.join(DATA, fn)
    if not os.path.exists(p): return []
    with open(p, encoding="utf-8-sig") as f: return list(csv.DictReader(f))


def days(iso):
    if not iso: return None
    try: d = datetime.date.fromisoformat(str(iso).strip())
    except Exception: return None
    return (d - datetime.date.today()).days


def build():
    clients = rows("clients.csv")
    products = rows("products.csv")
    materials = rows("materials.csv")
    talk = rows("talk.csv")
    events = rows("events.csv")
    tasks = rows("tasks.csv")
    links = rows("links.generated.csv")

    def rel(rel_name, src_type, dst_type):
        return [l for l in links if l.get("关系") == rel_name and l.get("来源类型") == src_type and l.get("目标类型") == dst_type]

    data = {
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "stages": STAGES,
        "clients": [{
            "id": c.get("客户ID", ""), "name": c.get("称谓", ""), "group": c.get("分群", ""),
            "stage": c.get("阶段", "线索"), "term": c.get("资金期限", ""), "dd": c.get("可承受回撤", ""),
            "risk": c.get("风险等级", ""), "next": c.get("下次联系日", ""), "last": c.get("上次沟通", ""),
            "worry": c.get("他真正担心什么", ""), "tags": c.get("标签", ""), "goal": c.get("目标", ""),
            "dueIn": days(c.get("下次联系日")), "lastIn": days(c.get("上次沟通")),
        } for c in clients],
        "products": [{
            "id": p.get("产品ID", ""), "name": p.get("名称", ""), "type": p.get("类型", ""),
            "risk": p.get("风险等级", ""), "status": p.get("状态", ""), "fit": p.get("适合谁", ""),
            "line": p.get("一句话话术", ""),
            "mentionedBy": [l.get("来源ID") for l in rel("提到", "客户", "产品") if l.get("目标ID") == p.get("产品ID")],
        } for p in products],
        "materials": [{
            "id": m.get("素材ID", ""), "title": m.get("标题", ""), "type": m.get("类型", ""),
            "talk": m.get("配好的话术", ""), "tags": m.get("适合标签", ""),
            "sentTo": [l.get("来源ID") for l in rel("发过", "客户", "素材") if l.get("目标ID") == m.get("素材ID")],
            "back": [l.get("来源ID") for l in rel("反馈过", "客户", "素材") if l.get("目标ID") == m.get("素材ID")],
        } for m in materials],
        "talk": [{"scene": t.get("场景", ""), "open": t.get("先接一句", ""), "fact": t.get("一个事实", ""), "next": t.get("一个下一步", "")} for t in talk],
        "events": [{"id": e.get("活动ID", ""), "name": e.get("名称", ""), "date": e.get("日期", ""), "time": e.get("时间", ""), "theme": e.get("主题", ""), "status": e.get("状态", "")} for e in events],
        "tasks": [{"task": t.get("任务", ""), "client": t.get("关联客户", ""), "done": t.get("是否完成", ""), "date": t.get("日期", "")} for t in tasks],
    }

    html = HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False))
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(html)
    return data


HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>一人投顾工作台</title>
<style>
:root{--ink:#26231f;--soft:#5a544c;--faint:#9b948a;--line:#e6e1d8;--line2:#efeae1;--paper:#fcfcf8;--accent:#c2571a;--accent-soft:#f7ede4;--warm:#f7f5ef;--bad:#b4431f}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:"Inter","PingFang SC","Microsoft YaHei",system-ui,sans-serif;font-size:13.5px;line-height:1.65}
.top{display:flex;align-items:center;gap:16px;padding:14px 22px;border-bottom:1px solid var(--line);background:#fff;position:sticky;top:0;z-index:20;flex-wrap:wrap}
.brand{font-family:Georgia,serif;font-size:16px;font-weight:600}
.grow{margin-left:auto;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
input.search{border:1px solid var(--line);border-radius:8px;padding:7px 12px;font-size:12.5px;font-family:inherit;width:180px}
.tabs{display:flex;gap:4px}.tabs button{border:0;background:none;padding:7px 12px;border-radius:8px;font-size:13px;color:var(--soft);cursor:pointer;font-family:inherit}
.tabs button.on{background:var(--ink);color:#fcfcf8}
.wrap{max-width:1240px;margin:0 auto;padding:18px 22px 70px}
.stats{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px}
.stat{border:1px solid var(--line);border-radius:10px;background:#fff;padding:10px 14px;min-width:104px}
.stat b{display:block;font-size:19px;font-family:Georgia,serif}.stat span{font-size:11px;color:var(--faint)}
.board{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
@media(max-width:920px){.board{grid-template-columns:1fr 1fr}}
.col{background:var(--warm);border-radius:12px;padding:10px;min-height:110px}
.col h3{font-size:12px;margin:2px 0 10px;color:var(--soft);display:flex;justify-content:space-between}
.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px;margin-bottom:8px;cursor:pointer}
.card:hover{border-color:var(--accent)}
.card .nm{font-weight:600;font-size:13px}.card .mt{font-size:11px;color:var(--faint);margin-top:3px}
.card .du{margin-top:5px;font-size:11px;color:var(--soft)}.du.over{color:var(--bad)}.du.soon{color:var(--accent)}
.pill{font-size:10px;padding:1px 6px;border-radius:4px;background:var(--accent-soft);color:var(--accent);margin-left:5px}
.pill.bad{background:#fbeae4;color:var(--bad)}
section{margin-top:22px;border:1px solid var(--line);border-radius:12px;background:#fff;padding:14px 16px}
section h2{font-size:13.5px;margin:0 0 10px;font-family:Georgia,serif}
.r{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line2);font-size:12.5px}
.r:last-child{border-bottom:0}.r .m{color:var(--faint);font-size:11px;white-space:nowrap}
.view{display:none}.view.on{display:block}
.drawer{position:fixed;top:0;right:0;height:100%;width:min(430px,94vw);background:var(--paper);border-left:1px solid var(--line);transform:translateX(102%);transition:.2s;z-index:40;display:flex;flex-direction:column}
.drawer.on{transform:none}
.dh{padding:16px 18px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between}
.dh h2{font-family:Georgia,serif;font-size:17px;margin:0}
.dh button{border:0;background:none;font-size:15px;color:var(--faint);cursor:pointer}
.db{padding:14px 18px;overflow:auto}
.kv{display:flex;justify-content:space-between;font-size:12.5px;padding:7px 0;border-bottom:1px dashed var(--line2)}
.kv span:first-child{color:var(--faint)}
.scrim{position:fixed;inset:0;background:rgba(38,35,31,.25);display:none;z-index:30}.scrim.on{display:block}
.muted{color:var(--faint);font-size:11.5px}
.foot{margin-top:26px;font-size:11.5px;color:var(--faint);line-height:1.8}
</style></head><body>
<div class="top">
  <div class="brand">一人投顾工作台</div>
  <div class="tabs" id="tabs">
    <button class="on" data-v="board">看板</button>
    <button data-v="products">产品</button>
    <button data-v="materials">素材</button>
    <button data-v="talk">话术</button>
    <button data-v="events">活动</button>
  </div>
  <div class="grow">
    <input class="search" id="q" placeholder="搜客户 / 产品 / 素材">
    <span class="muted" id="gen"></span>
  </div>
</div>
<div class="wrap">
  <div class="stats" id="stats"></div>

  <div class="view on" id="v-board">
    <div class="board" id="board"></div>
    <section><h2>本周该联系</h2><div id="due"></div></section>
    <section><h2>Gate 待补（发东西前先看）</h2><div id="gate"></div></section>
    <section><h2>沉默（60 天没联系）</h2><div id="sleep"></div></section>
    <section><h2>待办</h2><div id="tasks"></div></section>
  </div>

  <div class="view" id="v-products"><section><h2>产品库（出事时看这里，谁提到过）</h2><div id="plist"></div></section></div>
  <div class="view" id="v-materials"><section><h2>素材库（发了几个、回了几个）</h2><div id="mlist"></div></section></div>
  <div class="view" id="v-talk"><section><h2>话术卡</h2><div id="tlist"></div></section></div>
  <div class="view" id="v-events"><section><h2>活动</h2><div id="elist"></div></section></div>

  <div class="foot">数据来自 data/ 下的表；这个页面是快照，由 bench.py 生成。顾问不填表——他说话，AI 写表。</div>
</div>

<div class="scrim" id="scrim" onclick="closeD()"></div>
<div class="drawer" id="d"><div class="dh"><h2 id="dn"></h2><button onclick="closeD()">✕</button></div><div class="db" id="db"></div></div>

<script>
const D = __DATA__;
document.getElementById("gen").textContent = "生成于 " + D.generatedAt;
const esc = s => String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let Q = "";

function dueText(d){ if(d===null||d===undefined) return "未设跟进"; return d<0? "逾期 "+(-d)+" 天" : d===0? "今天" : d+" 天后"; }
function cls(d){ return d!==null&&d!==undefined&&d<0?"over":(d!==null&&d!==undefined&&d<=7?"soon":""); }

function render(){
  const cs = D.clients.filter(c => !Q || (c.name+c.tags+c.worry+c.goal).toLowerCase().includes(Q));
  // 统计
  const risk = c => (c.stage==="方案中"||c.stage==="已交付") && (!c.risk || !c.dd || !c.worry);
  document.getElementById("stats").innerHTML = [
    ["客户", D.clients.length],
    ["本周该联系", D.clients.filter(c=>c.dueIn!==null&&c.dueIn<=7).length],
    ["Gate 待补", D.clients.filter(risk).length],
    ["沉默", D.clients.filter(c=>c.lastIn!==null&&c.lastIn<=-60).length],
  ].map(([k,v])=>`<div class="stat"><b>${v}</b><span>${k}</span></div>`).join("");

  // 看板
  document.getElementById("board").innerHTML = D.stages.map(st=>{
    const g = cs.filter(c=>c.stage===st);
    return `<div class="col"><h3>${st}<em>${g.length}</em></h3>` + g.map(c=>
      `<div class="card" onclick="openC('${c.id}')">
        <div class="nm">${esc(c.name)}${c.risk?"":"<span class='pill bad'>未测评</span>"}</div>
        <div class="mt">${esc(c.group||"—")} · ${esc(c.term||"—")}</div>
        <div class="du ${cls(c.dueIn)}">${dueText(c.dueIn)}</div>
      </div>`).join("") + `</div>`;
  }).join("");

  // 三段
  const due = cs.filter(c=>c.dueIn!==null&&c.dueIn<=7).sort((a,b)=>a.dueIn-b.dueIn);
  document.getElementById("due").innerHTML = due.length ? due.map(c=>
    `<div class="r"><span><b>${esc(c.name)}</b>　${esc(c.worry||"—")}</span><span class="m">${dueText(c.dueIn)}</span></div>`).join("") : '<div class="muted">这周没有到期的。</div>';

  const gate = cs.filter(risk);
  document.getElementById("gate").innerHTML = gate.length ? gate.map(c=>{
    const miss=[]; if(!c.risk)miss.push("风险等级"); if(!c.dd)miss.push("可承受回撤"); if(!c.worry)miss.push("担心的事");
    return `<div class="r"><span><b>${esc(c.name)}</b>（${esc(c.stage)}）</span><span class="m">缺：${miss.join("、")}</span></div>`;
  }).join("") : '<div class="muted">没有卡住的。</div>';

  const sleep = cs.filter(c=>c.lastIn!==null&&c.lastIn<=-60);
  document.getElementById("sleep").innerHTML = sleep.length ? sleep.map(c=>
    `<div class="r"><span><b>${esc(c.name)}</b></span><span class="m">已 ${-c.lastIn} 天没联系</span></div>`).join("") : '<div class="muted">都在跟进中。</div>';

  document.getElementById("tasks").innerHTML = D.tasks.length ? D.tasks.map(t=>
    `<div class="r"><span>${esc(t.task)}</span><span class="m">${esc(t.done||"")}</span></div>`).join("") : '<div class="muted">没有待办。</div>';

  // 产品
  document.getElementById("plist").innerHTML = D.products.map(p=>{
    const warn = p.status && p.status!=="在售";
    return `<div class="r"><span><b>${esc(p.name)}</b>${warn?' <span class="pill bad">'+esc(p.status)+'</span>':''}　<span class="muted">${esc(p.type)} · ${esc(p.risk)}</span></span>
      <span class="m">提到过 ${p.mentionedBy.length} 人 ${p.mentionedBy.length? "· "+p.mentionedBy.join("、"):""}</span></div>`;
  }).join("") || '<div class="muted">产品库空着。</div>';

  // 素材
  document.getElementById("mlist").innerHTML = D.materials.map(m=>
    `<div class="r"><span><b>${esc(m.title)}</b>　<span class="muted">${esc(m.type)}</span></span>
     <span class="m">发 ${m.sentTo.length} 人 · 回 ${m.back.length} 人</span></div>`).join("") || '<div class="muted">素材库空着。</div>';

  // 话术
  document.getElementById("tlist").innerHTML = D.talk.map(t=>
    `<div class="r"><span><b>${esc(t.scene)}</b><br><span class="muted">${esc(t.open||"")}</span></span><span class="m">${esc(t.next||"")}</span></div>`).join("") || '<div class="muted">话术库空着。</div>';

  // 活动
  document.getElementById("elist").innerHTML = D.events.map(e=>
    `<div class="r"><span><b>${esc(e.name)}</b>　${esc(e.date)} ${esc(e.time)}　<span class="muted">${esc(e.theme)}</span></span><span class="m">${esc(e.status)}</span></div>`).join("") || '<div class="muted">没有排期。</div>';
}

function openC(id){
  const c = D.clients.find(x=>x.id===id); if(!c) return;
  document.getElementById("dn").textContent = c.name;
  document.getElementById("db").innerHTML = [
    ["阶段", c.stage], ["分群", c.group||"—"], ["资金期限", c.term||"—"],
    ["可承受回撤", c.dd?c.dd+"%":"—"], ["风险等级", c.risk||"未测评"],
    ["目标", c.goal||"—"], ["下次联系", c.next||"—"], ["上次沟通", c.last||"—"],
    ["他真正担心什么", c.worry||"—"], ["标签", c.tags||"—"],
  ].map(([k,v])=>`<div class="kv"><span>${k}</span><span>${esc(v)}</span></div>`).join("");
  document.getElementById("scrim").classList.add("on");
  document.getElementById("d").classList.add("on");
}
function closeD(){ document.getElementById("scrim").classList.remove("on"); document.getElementById("d").classList.remove("on"); }

document.getElementById("tabs").addEventListener("click", e=>{
  const b=e.target.closest("button[data-v]"); if(!b) return;
  document.querySelectorAll("#tabs button").forEach(x=>x.classList.toggle("on",x===b));
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("on"));
  document.getElementById("v-"+b.dataset.v).classList.add("on");
});
document.getElementById("q").addEventListener("input", e=>{ Q=e.target.value.trim().toLowerCase(); render(); });
render();
</script></body></html>
"""

if __name__ == "__main__":
    d = build()
    print(f"[OK] 已生成 {OUT}")
    print(f"     客户 {len(d['clients'])} · 产品 {len(d['products'])} · 素材 {len(d['materials'])} · 话术 {len(d['talk'])} · 活动 {len(d['events'])}")
    print("     在 WorkBuddy 里直接打开这个 html，就是工作台界面")
