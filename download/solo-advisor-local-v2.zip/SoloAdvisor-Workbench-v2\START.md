# 一人投顾工作台 · 文件包 v2

> 全量版：86 个功能点全覆盖。没有现成内容的地方，都给了一份**示例**，你改成自己的。

## 最重要的一条：顾问不填表

**顾问只说话，AI 写表。** 写入规则在 `AGENT-WRITE.md`（14 张表全覆盖）。
他只要说「今天见了张先生，他孩子两年后出国那 80 万不能亏」，AI 就去写 clients.csv。

## 三分钟上手

```bash
python check.py        # 体检：7 个 Gate + 数据完整性
python board.py        # 看板：五阶段 + 本周该联系 + Gate 待补 + 沉默 + 素材
python res.py 跌了      # 查弹药：场景/工具/Skill/库/模板
python calendar.py today  # 今天有几个会（需要 data/calendar.ics）
python links.py        # 关系自动生成（谁提到过哪个产品、素材发了几个）
```

## 改成你自己的（按顺序）

| 第几步 | 改哪个 | 说明 |
|---|---|---|
| 1 | `00-identity.md` | 你是谁、服务谁、四件不做 |
| 2 | `01-rules.md` | 你的执业边界 |
| 3 | `data/clients.csv` | **删掉 3 行 SAMPLE**，换成你的客户 |
| 4 | `data/products.csv` | 换成你能卖的产品；**「适合谁」「一句话话术」必须自己写** |
| 5 | `data/materials.csv`、`data/talk.csv` | 素材和话术，一天一条也行 |
| 6 | `templates/` 14 个 | 每个都有示例，改成你的版本 |

## 目录

```
SoloAdvisor-Workbench-v2/
├── START.md  CLAUDE.md  LOOP.md  CHECKLIST.md
├── 00-identity.md  01-rules.md
├── data/            14 张表（都有表头 + 示例行）
├── templates/       14 个交付物模板（都有示例内容）
├── clients/         客户卡（空模板 + 示例）
├── inbox/           客户一句话的分诊模板
├── resources/       场景33/工具28/Skill51/库75/模板20
├── plus/            schema / automations / roles（9 个角色）
├── outputs/         交付物
└── 脚本 board.py res.py check.py calendar.py sediment.py review.py sync.py act.py
```

## 数据在哪、怎么来

| 表 | 从哪来 |
|---|---|
| clients / family / referrals | 手工（你的客户） |
| products | 公开资料 + **你写的「适合谁/话术」** |
| materials / talk | 手工收 + 自己写 |
| sends / feedback | 发完记一笔 |
| events / invites | 沙龙前后填 |
| kpi | 只记你数得出来的 |
| calendar.ics | 从飞书/Outlook 下载放进 data/ |

> 每个表都有 SAMPLE 行，`check.py` 会提醒你还没换。