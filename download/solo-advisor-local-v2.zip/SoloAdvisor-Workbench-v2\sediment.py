"""沉淀：把用出来的新东西，写进 resources/local/

用法：
    python sediment.py scene "客户说：XX" "先接一句：…" --tag 情绪
    python sediment.py template "我的一页纸" "四段：位置/怎么做/最坏/何时再看"
    python sediment.py list

设计：
- 只写 resources/local/，不动站点导出的原始 JSON
- 每条带 source（谁给的）、date、status=pending（待复核）
- 复核通过后把 status 改成 approved；下次回流站点只取 approved
"""
import json, os, sys, datetime, argparse

ROOT = os.path.dirname(os.path.abspath(__file__))
LOCAL = os.path.join(ROOT, "resources", "local")
os.makedirs(LOCAL, exist_ok=True)

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

FILES = {"scene": "scenes.json", "template": "templates.json", "tool": "tools.json", "skill": "skills.json", "kb": "kb.json"}


def load(kind):
    p = os.path.join(LOCAL, FILES[kind])
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return []


def save(kind, data):
    p = os.path.join(LOCAL, FILES[kind])
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return p


def add(kind, title, body, tag=None, source="现场沉淀"):
    data = load(kind)
    item = {
        "id": f"local-{kind}-{len(data)+1:03d}",
        "title": title,
        "body": body,
        "tag": tag or "",
        "source": source,
        "date": datetime.date.today().isoformat(),
        "status": "pending",   # pending → approved
        "use_count": 0,
    }
    data.append(item)
    p = save(kind, data)
    print(f"[OK] 已写入 {p}")
    print(f"     {item['id']}  {title}")
    print(f"     状态 pending；复核后改成 approved 才会回流站点")


def show():
    total = 0
    for kind in FILES:
        data = load(kind)
        if not data:
            continue
        pending = [x for x in data if x.get("status") == "pending"]
        print(f"\n[{kind}] 共 {len(data)} 条，待复核 {len(pending)}")
        for x in data[-5:]:
            print(f"  · {x['id']}  {x['title']}  ({x['status']}, {x['date']})")
        total += len(data)
    if total == 0:
        print("还没有沉淀。用 python sediment.py scene \"客户说：…\" \"先接一句：…\" 加一条")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("kind", nargs="?", choices=list(FILES.keys()) + ["list"], default="list")
    ap.add_argument("title", nargs="?")
    ap.add_argument("body", nargs="?")
    ap.add_argument("--tag", default="")
    ap.add_argument("--source", default="现场沉淀")
    a = ap.parse_args()

    if a.kind == "list" or not a.title:
        show()
    else:
        add(a.kind, a.title, a.body or "", a.tag, a.source)
