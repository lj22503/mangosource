"""关系自动生成：不新增任何需要人填的表

顾问什么都不用做——他照常记客户、发素材、开沙龙，
这个脚本从已有的 14 张表里把关系「推导」出来，写到 data/links.generated.csv。

跑法：python links.py        （board.py 会自动调用它）
规则：
  1 sends.csv        → 客户 —发过→ 素材
  2 feedback.csv     → 客户 —反馈过→ 素材
  3 invites.csv      → 客户 —邀约/到场→ 活动
  4 clients.csv 标签  → 客户 —带标签→ 标签
  5 自由文本里出现产品名 → 客户 —提到→ 产品（含「他真正担心什么」「反馈原话」）
"""
import csv, os, sys, re

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(DATA, "links.generated.csv")

try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass


def load(fn):
    p = os.path.join(DATA, fn)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def norm(s):
    return (s or "").strip()


def build():
    clients = load("clients.csv")
    products = load("products.csv")
    materials = load("materials.csv")
    sends = load("sends.csv")
    feedback = load("feedback.csv")
    invites = load("invites.csv")
    events = load("events.csv")

    links = []
    def add(src_t, src_id, rel, dst_t, dst_id, evidence=""):
        if not src_id or not dst_id:
            return
        links.append({
            "来源类型": src_t, "来源ID": src_id, "关系": rel,
            "目标类型": dst_t, "目标ID": dst_id, "证据": evidence,
        })

    # 1 发送
    for s in sends:
        add("客户", norm(s.get("客户ID")), "发过", "素材", norm(s.get("素材ID")), f"{norm(s.get('日期'))} {norm(s.get('渠道'))}")

    # 2 反馈：用「该客户最近一次收到的素材」推导，顾问不用填素材ID
    last_send = {}
    for s_ in sends:
        cid, mid, d = norm(s_.get("客户ID")), norm(s_.get("素材ID")), norm(s_.get("日期"))
        if cid and mid and (cid not in last_send or d >= last_send[cid][1]):
            last_send[cid] = (mid, d)
    for f in feedback:
        cid = norm(f.get("客户ID"))
        mid = last_send.get(cid, ("", ""))[0]
        add("客户", cid, "反馈过", "素材", mid, norm(f.get("反馈原话"))[:24])

    # 3 活动
    for i in invites:
        rel = "到场" if norm(i.get("是否到场")) in ("是", "Y", "y", "1") else "邀约"
        add("客户", norm(i.get("客户ID")), rel, "活动", norm(i.get("活动ID")), f"{norm(i.get('邀约日期'))} {norm(i.get('渠道'))}")

    # 4 标签
    for c in clients:
        cid = norm(c.get("客户ID"))
        for t in re.split(r"[|,;、]", norm(c.get("标签"))):
            if t.strip():
                add("客户", cid, "带标签", "标签", t.strip(), "")

    # 5 自由文本里提到产品
    names = [(norm(p.get("产品ID")), norm(p.get("名称"))) for p in products if norm(p.get("名称"))]
    texts = []
    for c in clients:
        texts.append((norm(c.get("客户ID")), "他真正担心什么", norm(c.get("他真正担心什么"))))
        texts.append((norm(c.get("客户ID")), "备注", norm(c.get("备注"))))
    for f in feedback:
        texts.append((norm(f.get("客户ID")), "反馈原话", norm(f.get("反馈原话"))))

    for cid, where, text in texts:
        if not text:
            continue
        for pid, pname in names:
            key = pname.replace("XX", "")  # 示例产品名带 XX 前缀，去掉再匹配
            if key and key in text:
                add("客户", cid, "提到", "产品", pid, f"{where}：{text[:24]}")

    # 去重
    seen, uniq = set(), []
    for l in links:
        k = (l["来源类型"], l["来源ID"], l["关系"], l["目标类型"], l["目标ID"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(l)

    with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["来源类型","来源ID","关系","目标类型","目标ID","证据"])
        w.writeheader()
        w.writerows(uniq)
    return uniq


def summary(links):
    by_rel = {}
    for l in links:
        by_rel[l["关系"]] = by_rel.get(l["关系"], 0) + 1
    return by_rel


if __name__ == "__main__":
    ls = build()
    print(f"[OK] 生成 {OUT}")
    print(f"     关系 {len(ls)} 条：" + " · ".join(f"{k} {v}" for k, v in summary(ls).items()))
    print("     顾问不用填任何东西，照常干活即可")
