"""日历：读 ICS（只读）与生成 .ics（写回）

用法：
    python calendar.py today          # 今天有几个会、跟谁（读 data/calendar.ics）
    python calendar.py add "张先生" 2026-12-01 14:00 30   # 生成一条 .ics 到 outputs/

说明：
- ICS 是只读订阅，所以「读」靠订阅文件，「写」靠生成 .ics 文件让你双击导入
- 把飞书/Outlook 日历的 ICS 订阅链接下回来，存成 data/calendar.ics 即可
"""
import os, sys, datetime, re

ROOT = os.path.dirname(os.path.abspath(__file__))
ICS = os.path.join(ROOT, "data", "calendar.ics")
OUT = os.path.join(ROOT, "outputs")
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass

def read_ics(path):
    if not os.path.exists(path): return []
    txt = open(path, encoding="utf-8", errors="replace").read()
    txt = txt.replace("\r\n ", "").replace("\n ", "")
    events=[]
    for block in re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", txt, re.S):
        def g(k):
            m=re.search(k+r"[^:]*:([^\r\n]+)", block)
            return m.group(1).strip() if m else ""
        events.append({"summary":g("SUMMARY"),"dtstart":g("DTSTART"),"dtend":g("DTEND"),"location":g("LOCATION")})
    return events

def today():
    evs = read_ics(ICS)
    if not evs:
        print("没有 data/calendar.ics。把日历的 ICS 订阅下载下来放进去，就能看今天有几个会。")
        return
    d = datetime.date.today().strftime("%Y%m%d")
    todays=[e for e in evs if d in e["dtstart"]]
    print(f"今天（{datetime.date.today()}）共 {len(todays)} 个日程：")
    for e in todays:
        t = e["dtstart"][9:13]
        print(f"  {t[:2]}:{t[2:]}  {e['summary']}")

def add(name, date, time, minutes):
    if not os.path.isdir(OUT): os.makedirs(OUT)
    start = datetime.datetime.strptime(f"{date} {time}", "%Y-%m-%d %H:%M")
    end = start + datetime.timedelta(minutes=int(minutes))
    fmt = lambda x: x.strftime("%Y%m%dT%H%M%S")
    ics = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//SoloAdvisor//Workbench//CN
BEGIN:VEVENT
UID:{fmt(start)}-{abs(hash(name))%10000}@solo
DTSTAMP:{fmt(datetime.datetime.now())}
DTSTART:{fmt(start)}
DTEND:{fmt(end)}
SUMMARY:面谈 · {name}
DESCRIPTION:会前备料：他的档案 + 上次说了什么 + 这次要定的三件事
END:VEVENT
END:VCALENDAR
"""
    p = os.path.join(OUT, f"{date.replace('-','')}-{name}-面谈.ics")
    open(p, "w", encoding="utf-8").write(ics)
    print(f"[OK] 已生成 {p}")
    print("     双击导入日历，或拖进 Outlook/飞书")

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "today": today()
    elif a[0] == "add" and len(a) >= 4: add(a[1], a[2], a[3], a[4] if len(a)>4 else 30)
    else: print(__doc__)
