"""资源检索：在站点五层资源里按关键词找东西

跑法：
    python res.py 跌了
    python res.py 估值
    python res.py 客户档案

输出：场景 / 工具 / Skill / 知识库 / 模板 五段命中，带链接或复制键。
"""
import json, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "resources", "_all.json")

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def load():
    with open(DATA, encoding="utf-8") as f:
        return json.load(f)


def flat_tools(tools):
    out = []
    for g in tools:
        if not isinstance(g, list) or len(g) < 2:
            continue
        layer, items = g[0], g[1]
        for t in items or []:
            out.append({"layer": layer, "name": t[0], "desc": t[1], "kind": t[2], "url": t[3], "tpl": t[4] if len(t) > 4 else None})
    return out


def main(kw):
    d = load()
    kw_l = kw.lower()
    hit = lambda *xs: any(kw_l in str(x).lower() for x in xs if x)

    print(f"\n🔍 关键词：{kw}\n" + "=" * 60)

    # 1 场景
    scenes = [s for s in d.get("SCENES", []) if hit(s.get("t"), s.get("v"))]
    print(f"\n【场景】{len(scenes)} 条（你该怎么接）")
    for s in scenes[:5]:
        print(f"  · 客户说：「{s.get('t')}」")
        print(f"    先接一句：{s.get('v','')}")
        if s.get("end"):
            print(f"    让他做：{s.get('end')}")

    # 2 工具
    tools = [t for t in flat_tools(d.get("TOOLS", [])) if hit(t["name"], t["desc"])]
    print(f"\n【工具】{len(tools)} 个（去哪查）")
    for t in tools[:5]:
        print(f"  · {t['name']}（{t['layer']}·{t['kind']}）{t['desc']}")
        print(f"    {t['url']}")

    # 3 Skill
    skills = [s for s in d.get("SKILLS", []) if hit(s[1], s[2])]
    print(f"\n【Skill】{len(skills)} 个（谁来干）")
    for s in skills[:5]:
        print(f"  · {s[1]}（{s[0]}）{s[2]}")
        print(f"    {s[6]}")

    # 4 知识库
    lib = [x for x in d.get("LIB", []) if hit(x[1], x[4])]
    print(f"\n【知识库】{len(lib)} 个（依据从哪来）")
    for x in lib[:5]:
        print(f"  · {x[1]}（{x[0]}）{x[4]}")
        print(f"    {x[5] if x[5] else '复制库名搜索：' + x[1]}")

    # 5 模板
    tpl = d.get("TPL", {})
    tpl_hits = [(k, v) for k, v in tpl.items() if hit(v.get("t"), v.get("target"))]
    print(f"\n【模板】{len(tpl_hits)} 个（交什么出去）")
    for k, v in tpl_hits[:5]:
        print(f"  · {v.get('t')}　{v.get('target','')}")
        print(f"    键：{k}")

    total = len(scenes) + len(tools) + len(skills) + len(lib) + len(tpl_hits)
    print("\n" + "=" * 60)
    print(f"共命中 {total} 条（场景 {len(scenes)} / 工具 {len(tools)} / Skill {len(skills)} / 库 {len(lib)} / 模板 {len(tpl_hits)}）\n")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法：python res.py <关键词>")
        sys.exit(0)
    main(sys.argv[1])
