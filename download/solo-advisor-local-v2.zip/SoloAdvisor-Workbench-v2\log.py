"""写表：给 AI 用的安全写入工具（顾问不碰）

用法（AI 在对话里调）：
    python log.py client  C004 "王女士" --set 分群=成长 --set 阶段=线索
    python log.py send    C001 M001 微信
    python log.py feedback C001 "看不懂" 看不懂 是
    python log.py invite  E001 C002 微信 是
    python log.py task    "联系李女士" C002 跟进
    python log.py material "降准0.5个点" 宏观 "存款利息可能再降" "这条跟你有关…"
    python log.py product P004 "XX短债" 公募债 R2 随时 0.2% --set 适合谁=C1-C2 --set 状态=在售
    python log.py event   E002 "月度直播" 直播 2026-12-05 20:00 线上 "四季度怎么收"
    python log.py kpi     2026-12 --set 新增客户=3
    python log.py payment C001 2026-11-27      # 记一次沟通（更新上次沟通）

设计原则：
- 只追加/更新，不删；同一行重复调用不会产生重复记录（按主键去重）
- 自动补 ID（C004/M003/E002/P004）、自动补日期
- 表头以 data/ 下现有 CSV 为准，缺字段留空
"""
import csv, os, sys, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, "data")
TODAY = datetime.date.today().isoformat()

try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception: pass

SPEC = {
    "client":    ("clients.csv", "客户ID", ["称谓","家庭ID","分群","来源","阶段","资金期限","可承受回撤","风险等级","测评日期","目标","决策人","标签","下次联系日","上次沟通","他真正担心什么","备注"]),
    "family":    ("family.csv", "家庭ID", ["家庭称谓","成员","关系","家庭可投资产","备注"]),
    "referral":  ("referrals.csv", None, ["推荐人","被推荐人","推荐日期","关系","是否回访","回访日期","备注"]),
    "product":   ("products.csv", "产品ID", ["名称","类型","风险等级","期限","费率","近3年年化","最大回撤","适合谁","一句话话术","状态","我的理解","更新日期"]),
    "material":  ("materials.csv", "素材ID", ["标题","类型","来源","日期","摘要","配好的话术","适合标签","已发人数"]),
    "talk":      ("talk.csv", "T001", ["场景","客户原话","先接一句","一个事实","一个下一步","分层(新手/老手/保守)","使用次数"]),
    "send":      ("sends.csv", None, ["日期","客户ID","素材ID","渠道","是否已读","反馈","下一步"]),
    "feedback":  ("feedback.csv", None, ["日期","客户ID","反馈原话","属于哪类","是否需要跟进","处理方式"]),
    "event":     ("events.csv", "活动ID", ["名称","类型","日期","时间","地点","主题","目标人数","策划要点","状态","会后跟进期限"]),
    "invite":    ("invites.csv", None, ["活动ID","客户ID","邀约日期","渠道","是否确认","是否到场","现场问题","会后跟进"]),
    "task":      ("tasks.csv", None, ["日期","任务","关联客户","类型","是否完成","备注"]),
    "topic":     ("topics.csv", None, ["选题","来源(客户问题/热点/投教)","目标读者","形态(长文/图/短视频)","计划日期","状态"]),
    "note":      ("notes.csv", None, ["产品ID或主题","我的理解三句话","更新日期"]),
    "kpi":       ("kpi.csv", "月份", ["新增客户","流失客户","素材发送数","面访数","电访数","沙龙场次","备注"]),
}


def path_of(fn): return os.path.join(DATA, fn)


def read(fn):
    p = path_of(fn)
    if not os.path.exists(p): return [], []
    with open(p, encoding="utf-8-sig") as f:
        rd = csv.DictReader(f)
        return list(rd.fieldnames or []), list(rd)


def write(fn, head, rows):
    p = path_of(fn)
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=head)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in head})


def next_id(head, rows, key, prefix):
    used = {str(r.get(key, "")) for r in rows}
    i = 1
    while f"{prefix}{i:03d}" in used:
        i += 1
    return f"{prefix}{i:03d}"


def upsert(kind, key_val, values):
    fn, key, cols = SPEC[kind]
    head, rows = read(fn)
    if not head:
        head = ([key] if key else []) + cols
    for r in rows:
        if key and str(r.get(key)) == str(key_val):
            for k, v in values.items():
                if k in head: r[k] = v
            write(fn, head, rows)
            print(f"[OK] 更新 {fn} 第 {key_val} 行")
            return
    row = {k: "" for k in head}
    if key: row[key] = key_val
    for k, v in values.items():
        if k in head: row[k] = v
    rows.append(row)
    write(fn, head, rows)
    print(f"[OK] 新增 {fn} {key_val}")


def append(kind, kv):
    fn, key, cols = SPEC[kind]
    head, rows = read(fn)
    if not head: head = ([key] if key else []) + cols
    row = {k: "" for k in head}
    for k, v in kv.items():
        if k in head: row[k] = v
    # 去重：同客户+同素材+同日期 视为同一条
    sig = (row.get("日期"), row.get("客户ID"), row.get("素材ID"), row.get("任务"), row.get("项目", ""))
    for r in rows:
        if (r.get("日期"), r.get("客户ID"), r.get("素材ID"), r.get("任务"), "") == sig and any(sig[:3]):
            print(f"[SKIP] 已存在相同记录")
            return
    rows.append(row)
    write(fn, head, rows)
    print(f"[OK] 追加 {fn}：{ {k: v for k, v in kv.items() if v} }")


def parse(argv):
    pos, kv = [], {}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--set":
            i += 1
            if "=" in argv[i]:
                k, v = argv[i].split("=", 1)
                kv[k] = v
        elif "=" in a:
            k, v = a.split("=", 1)
            kv[k] = v
        else:
            pos.append(a)
        i += 1
    return pos, kv


def main():
    if len(sys.argv) < 2:
        print(__doc__); return
    kind = sys.argv[1]
    pos, kv = parse(sys.argv[2:])

    if kind == "send" and len(pos) >= 2:
        append("send", {"日期": kv.pop("日期", TODAY), "客户ID": pos[0], "素材ID": pos[1], "渠道": kv.pop("渠道", "微信"), **kv})
    elif kind == "feedback" and len(pos) >= 2:
        append("feedback", {"日期": kv.pop("日期", TODAY), "客户ID": pos[0], "反馈原话": pos[1], "属于哪类": pos[2] if len(pos) > 2 else "", "是否需要跟进": pos[3] if len(pos) > 3 else "", **kv})
    elif kind == "invite" and len(pos) >= 2:
        append("invite", {"活动ID": pos[0], "客户ID": pos[1], "邀约日期": kv.pop("邀约日期", TODAY), "渠道": kv.pop("渠道", "微信"), "是否确认": kv.pop("是否确认", "待回"), "是否到场": kv.pop("是否到场", ""), **kv})
    elif kind == "task" and pos:
        append("task", {"日期": kv.pop("日期", TODAY), "任务": pos[0], "关联客户": pos[1] if len(pos) > 1 else "", "类型": pos[2] if len(pos) > 2 else "", "是否完成": kv.pop("是否完成", "否"), **kv})
    elif kind == "material" and pos:
        head, rows = read("materials.csv")
        mid = next_id(head, rows, "素材ID", "M")
        append("material", {"素材ID": mid, "标题": pos[0], "类型": pos[1] if len(pos) > 1 else "", "日期": kv.pop("日期", TODAY), "摘要": pos[2] if len(pos) > 2 else "", "配好的话术": pos[3] if len(pos) > 3 else "", **kv})
    elif kind == "product" and pos:
        head, rows = read("products.csv")
        pid = pos[0] if pos[0].startswith("P") else next_id(head, rows, "产品ID", "P")
        order = ["名称","类型","风险等级","期限","费率"]
        vals = {order[i]: pos[i+1] for i in range(len(pos)-1) if i < len(order)}
        vals["更新日期"] = TODAY
        vals.update(kv)
        upsert("product", pid, vals)
    elif kind == "client" and pos:
        head, rows = read("clients.csv")
        if pos[0].startswith("C") and len(pos[0]) <= 8:
            cid = pos[0]
            vals = ({"称谓": pos[1]} if len(pos) > 1 else {})
        else:
            cid = next_id(head, rows, "客户ID", "C")
            vals = {"称谓": pos[0]}
        vals.update(kv)
        upsert("client", cid, vals)
    elif kind == "event" and pos:
        head, rows = read("events.csv")
        eid = pos[0] if pos[0].startswith("E") else next_id(head, rows, "活动ID", "E")
        order = ["名称","类型","日期","时间","地点","主题"]
        vals = {order[i]: pos[i+1] for i in range(len(pos)-1) if i < len(order)}
        vals.update(kv)
        upsert("event", eid, vals)
    elif kind == "kpi" and pos:
        upsert("kpi", pos[0], kv)
    elif kind == "talk" and pos:
        head, rows = read("talk.csv")
        tid = f"T{len(rows)+1:03d}"
        append("talk", {"场景": pos[0], "先接一句": pos[1] if len(pos) > 1 else "", "一个事实": pos[2] if len(pos) > 2 else "", "一个下一步": pos[3] if len(pos) > 3 else "", **kv})
    elif kind == "payment" and pos:
        upsert("client", pos[0], {"上次沟通": pos[1] if len(pos) > 1 else TODAY, **kv})
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
