"""回流：把 approved 的本地沉淀合并进 resources/_all.json

用法：
    python sync.py            # 只看会合并几条（dry run）
    python sync.py --write    # 真写

规则：
- 只取 status=approved
- 合并到对应层，加 "origin": "local"，不覆盖站点原条目
- rejected / pending 一律不动
"""
import json, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
LOCAL = os.path.join(ROOT, "resources", "local")
ALL = os.path.join(ROOT, "resources", "_all.json")
FILES = {"scene": "scenes.json", "template": "templates.json", "tool": "tools.json", "skill": "skills.json", "kb": "kb.json"}
KEY = {"scene": "SCENES", "template": "TPL", "tool": "TOOLS", "skill": "SKILLS", "kb": "LIB"}

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def main(write=False):
    with open(ALL, encoding="utf-8") as f:
        all_data = json.load(f)

    added = {}
    for kind, fn in FILES.items():
        p = os.path.join(LOCAL, fn)
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8") as f:
            items = [x for x in json.load(f) if x.get("status") == "approved"]
        if not items:
            continue
        layer = KEY[kind]
        if kind == "template":
            tpl = all_data.setdefault("TPL", {})
            for x in items:
                k = f"local_{x['id']}"
                if k in tpl:
                    continue
                tpl[k] = {"t": x["title"], "target": x["body"][:200], "preview": x["body"], "locked": "", "origin": "local", "date": x["date"]}
                added[kind] = added.get(kind, 0) + 1
        else:
            arr = all_data.setdefault(layer, [])
            have = {str(x) for x in arr}
            for x in items:
                marker = x["title"]
                if any(marker in str(h) for h in arr):
                    continue
                if kind == "scene":
                    arr.append({"t": x["title"].replace("客户说：", ""), "v": x["body"], "tags": [x.get("tag", "")], "origin": "local", "date": x["date"]})
                else:
                    arr.append({"name": x["title"], "body": x["body"], "tag": x.get("tag", ""), "origin": "local", "date": x["date"]})
                added[kind] = added.get(kind, 0) + 1

    if not added:
        print("没有 approved 的条目可回流。")
        return

    print("将合并：", json.dumps(added, ensure_ascii=False))
    if write:
        with open(ALL, "w", encoding="utf-8") as f:
            json.dump(all_data, f, ensure_ascii=False, indent=2)
        print(f"[OK] 已写入 {ALL}")
        print("     下次站点更新时，把 origin=local 的条目一起带过去")
    else:
        print("（dry run，没写盘；加 --write 才真写）")


if __name__ == "__main__":
    main("--write" in sys.argv)
